
# Billing Management System |
LEARNINGS :-> Java,Java Swing, Oops, MySQL, Java AWT , DSA
• Developed a Java application using with Java Swing and Oops Concepts
• In this project i Create multiple Frames and they are connected each frame frame using Oops concepts
• In this project i use SQL as a Database in this database i store complete data of my Billing-System , i create
multiple tables for each function.
• https://github.com/Nickhil215/Billing-System


## Color Reference

| Color             | Hex                                                                |
| ----------------- | ------------------------------------------------------------------ |
| Background Color | ![#3e538f](https://via.placeholder.com/10x10/3e538f/3e538f) #3e538f |
| Text Color | ![#ffffff](https://via.placeholder.com/10x10/ffffff/ffffff) #ffffff |
| Logo Color | ![#f2ef4b](https://via.placeholder.com/10x10/f2ef4b/f2ef4b) #f2ef4b |
| Other Color | ![#000000](https://via.placeholder.com/10x10/000000/000000) #000000 |


## Screenshots

![Untitled_AdobeExpress](https://user-images.githubusercontent.com/105160327/216155795-b502e403-49a6-43a1-a9cf-dc6b86b4a87a.gif)


![LOGIN](https://user-images.githubusercontent.com/105160327/216158049-04095c99-8a29-4699-96d7-4d8c166b98dd.jpg)

THIS IS LOGIN PAGE HERE WE ENTER THE OWNER USER NAME AND HIS/HER PASSWORD IF THE USER NAME AND PASSWORD IS CORRECT THEN ONLY HE WILL ENTER INTO THE APPLIANCE AND HE CAN ACCESS THE APPLIANCE IF USER NAME AND PASSWORD MATCH.


![landing page](https://user-images.githubusercontent.com/105160327/216158243-9f575b0b-949f-403f-aa88-6c31f69efaad.jpg)

IF THE USERNAME AND PASSWORD IS CORRECT THEN USER ENTER INTO THE APPLIANCE THIS IS THE OUR APPLIANCE lANDING PAGE IF CLICK THAT CLICK HERE DUTTON IT SHOWS OPTION'S.

![options](https://user-images.githubusercontent.com/105160327/216158309-992e1420-91cb-4532-a32d-d2207e2d2fef.jpg)

  THIS IS OUR APPLIANCE MENU .

![new buyer](https://user-images.githubusercontent.com/105160327/216158439-44010380-916a-46cf-8bf7-58dcbbf368d6.jpg)

IF A NEW CUSTOMER ENTER INTO OUR SHOP AT THAT TIME WE ENTER THAT CUSTOMER DETAILS INTO OUR DATABASE  USING THIS OPTION HERE WE ENTER CUSTOMER NAME , EMAIL, GENDER, CONTACT NUMBER, AND ADDRESS.

![update buyer](https://user-images.githubusercontent.com/105160327/216158444-94701606-f759-4c32-a095-5adfe464c3f6.jpg)

USING THIS OPTION WE CAN update OUR BUYERS  DETAILS

![buyer details ](https://user-images.githubusercontent.com/105160327/216158447-3c60874c-d30c-460b-867b-1aafb75ce76f.jpg)

IF WE CLICK THIS OPTION HERE IT SHOWS COMPLETE DETAILS ABOUT  OUR CUSTOMERS

![delete buyer](https://user-images.githubusercontent.com/105160327/216158397-48493f79-2d3a-42e2-8112-3e8b0709af99.jpg)

BY USING THIS OPTION  WE CAN DELETE CUSTOMER 

![new product](https://user-images.githubusercontent.com/105160327/216158409-8feef70a-27f3-4374-8723-2e6b63b64185.jpg)
 
 BY USNG THIS OPTIONWE CAN ADD NEW PRODUCT INTO OUR DATABASE AND WHILE ADDING PROCESS HERE WE CAN ASSIGN PRODUCT ID ALSO IT GENERATED AUTOMATICALLY AND IT IS USED TO SEARCH PRODUCT 

![update product](https://user-images.githubusercontent.com/105160327/216158412-b3e87bb0-7210-456f-b9e5-330e1fe6f46b.jpg)

BY USING THIS OPTION WE CAN EDIT PRODUCT DETAILS 

![product details ](https://user-images.githubusercontent.com/105160327/216158419-d9828fdb-fa69-497d-87b4-644f6cd426aa.jpg)

IF CLICK THIS IN MENU IT SHOWS COMPLETE LIST OF PRODUCTS.

![delete product](https://user-images.githubusercontent.com/105160327/216158422-5388a4ce-1a75-44b3-91eb-f7fb9b4640a2.jpg)
 HERE WE CAN DELETE PRODUCT BY USING PRODUCT ID 

![billing](https://user-images.githubusercontent.com/105160327/216158424-d71337e8-f67d-4cf7-b65e-a695549e98ca.jpg)
THIS IS THE MAIN PART OF OUR APPLIANCE HERE WE CAN GENERATE OUR BILL BY USING CUSTOMER DETAILS AND PRODUCT DETAILS 

![bill generated ](https://user-images.githubusercontent.com/105160327/216158427-57d907a5-c487-4a3d-b419-7c0e51f2a766.jpg)
HERE THE IS GENERATED
![log out](https://user-images.githubusercontent.com/105160327/216158428-ac7ab6fe-c48b-4e5a-b024-4a0bcce3b7fd.jpg)
LOGOUT

![bill](https://user-images.githubusercontent.com/105160327/216158436-9b452ed7-16d4-48eb-a6c4-06c32377da95.jpg)



THIS IS THE GENERATED BILL ,THE BILL WILL BE GENERATED LIKE THIS ONLY 
